package com.openpositioning.PositionMe.fragments;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.preference.PreferenceManager;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.GroundOverlay;
import com.google.android.gms.maps.model.GroundOverlayOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.openpositioning.PositionMe.R;
import com.openpositioning.PositionMe.sensors.SensorFusion;
import com.openpositioning.PositionMe.sensors.SensorTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass. The recording fragment is displayed while the app is actively
 * saving data, with some UI elements indicating current PDR status.
 *
 * @see HomeFragment the previous fragment in the nav graph.
 * @see CorrectionFragment the next fragment in the nav graph.
 * @see SensorFusion the class containing sensors and recording.
 *
 * @author Mate Stodulka
 */
public class RecordingFragment extends Fragment {

    //Button to end PDR recording
    private Button stopButton;
    private Button cancelButton;
    //Recording icon to show user recording is in progress
    private ImageView recIcon;
    //Compass icon to show user direction of heading
    private ImageView compassIcon;
    // Elevator icon to show elevator usage
    private ImageView elevatorIcon;
    //Loading bar to show time remaining before recording automatically ends
    private ProgressBar timeRemaining;
    //Text views to display user position and elevation since beginning of recording
    private TextView positionX;
    private TextView positionY;
    private TextView elevation;
    private TextView distanceTravelled;

    //App settings
    private SharedPreferences settings;
    //Singleton class to collect all sensor data
    private SensorFusion sensorFusion;
    //Timer to end recording
    private CountDownTimer autoStop;
    //?
    private Handler refreshDataHandler;

    // Variables to store data of the trajectory
    private float distance;
    private float previousPosX;
    private float previousPosY;
    private Polyline pdrPolyline;
    private List<LatLng> polyLineArray = new ArrayList<>(); // Saves positions for path tracking
    private LatLng lastPosition = null; // Track the last position

    // Map Variables
    private GoogleMap mMap;
    private Marker currentMarker;
    private float zoom = 19.2f;

    // Overlay variables
    private Map<String, GroundOverlayOptions> floorOverlayOptionsMap = new HashMap<>();
    private GroundOverlay currentOverlay;
    private String currentBuilding = "";
    private String currentFloor = "G";
    private String selectedFloor = "G";

    // Variable to convert latitude coordinates to radians
    double startLatRadians = Math.toRadians(StartLocationFragment.startPosition[0]);


    /**
     * Public Constructor for the class.
     * Left empty as not required
     */
    public RecordingFragment() {
        // Required empty public constructor
    }


    /**
     * {@inheritDoc}
     * Gets an instance of the {@link SensorFusion} class, and initialises the context and settings.
     * Creates a handler for periodically updating the displayed data.
     *
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.sensorFusion = SensorFusion.getInstance();
        Context context = getActivity();
        this.settings = PreferenceManager.getDefaultSharedPreferences(context);
        this.refreshDataHandler = new Handler();
    }


    /**
     * {@inheritDoc}
     * Set title in action bar to "Recording"
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_recording, container, false);
        // Inflate the layout for this fragment
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
        getActivity().setTitle("Recording...");
        // Adds button to choose Map Type
        setupMapTypeButton(rootView);
        return rootView;
    }

    /**
     * Links Pop-Up Menu to "Map Type" button on the interface
     * Allows user to choose between different Map types from interactive menu
     * @param rootView
     */
    private void setupMapTypeButton(View rootView) {
        // Linking method to the interface button
        Button mapTypeButton = rootView.findViewById(R.id.buttonMapType);
        mapTypeButton.setOnClickListener(new View.OnClickListener() {

            /**
             * OnClick listener for button to change map type
             * When button clicked a Pop-Up menu brings up selectable map types for user
             */
            @Override
            public void onClick(View v) {
                // Creating Pop-Up Menu
                PopupMenu popupMenu = new PopupMenu(getActivity(), v);
                // Inflating the Pop-Up Menu with the map types
                popupMenu.getMenu().add(Menu.NONE, GoogleMap.MAP_TYPE_NORMAL, Menu.NONE, "Normal");
                popupMenu.getMenu().add(Menu.NONE, GoogleMap.MAP_TYPE_SATELLITE, Menu.NONE, "Satellite");
                popupMenu.getMenu().add(Menu.NONE, GoogleMap.MAP_TYPE_TERRAIN, Menu.NONE, "Terrain");
                popupMenu.getMenu().add(Menu.NONE, GoogleMap.MAP_TYPE_HYBRID, Menu.NONE, "Hybrid");

                // Setting up click listener for the menu options
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

                    /**
                     * OnMenuItemClick listener for map type Pop-Up menu options
                     * When an option is clicked it will set the google map to that type
                     */
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        // Setting map type based on user selection
                        mMap.setMapType(item.getItemId());
                        return true;
                    }
                });

                // Showing the Pop-Up Menu
                popupMenu.show();
            }
        });
    }
    

    /**
     * {@inheritDoc}
     * Text Views and Icons initialised to display the current PDR to the user. A Button onClick
     * listener is enabled to detect when to go to next fragment and allow the user to correct PDR.
     * A runnable thread is called to update the UI every 0.5 seconds.
     */
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Set autoStop to null for repeat recordings
        this.autoStop = null;

        // Initialise UI components
        this.positionX = getView().findViewById(R.id.currentXPos);
        this.positionY = getView().findViewById(R.id.currentYPos);
        this.elevation = getView().findViewById(R.id.currentElevation);
        this.distanceTravelled = getView().findViewById(R.id.currentDistanceTraveled);
        this.compassIcon = getView().findViewById(R.id.compass);
        this.elevatorIcon = getView().findViewById(R.id.elevatorImage);

        // Set default text of TextViews to 0
        this.positionX.setText(getString(R.string.x, "0"));
        this.positionY.setText(getString(R.string.y, "0"));
        this.positionY.setText(getString(R.string.elevation, "0"));
        this.distanceTravelled.setText(getString(R.string.meter, "0"));

        // Reset variables to 0
        this.distance = 0f;
        this.previousPosX = 0f;
        this.previousPosY = 0f;

        // Stop button to save trajectory and move to corrections
        this.stopButton = getView().findViewById(R.id.stopButton);
        this.stopButton.setOnClickListener(new View.OnClickListener() {

            /**
             * {@inheritDoc}
             * OnClick listener for button to go to next fragment.
             * When button clicked the PDR recording is stopped and the {@link CorrectionFragment} is loaded.
             */
            @Override
            public void onClick(View view) {
                if(autoStop != null) autoStop.cancel();
                sensorFusion.stopRecording();
                NavDirections action = RecordingFragmentDirections.actionRecordingFragmentToCorrectionFragment();
                Navigation.findNavController(view).navigate(action);
            }
        });

        // Cancel button to discard trajectory and return to Home
        this.cancelButton = getView().findViewById(R.id.cancelButton);
        this.cancelButton.setOnClickListener(new View.OnClickListener() {

            /**
             * {@inheritDoc}
             * OnClick listener for button to go to home fragment.
             * When button clicked the PDR recording is stopped and the {@link HomeFragment} is loaded.
             * The trajectory is not saved.
             */
            @Override
            public void onClick(View view) {
                sensorFusion.stopRecording();
                NavDirections action = RecordingFragmentDirections.actionRecordingFragmentToHomeFragment();
                Navigation.findNavController(view).navigate(action);
                if(autoStop != null) autoStop.cancel();
            }
        });

        // Display the progress of the recording when a max record length is set
        this.timeRemaining = getView().findViewById(R.id.timeRemainingBar);

        // Display a blinking red dot to show recording is in progress
        blinkingRecording();

        // Check if there is manually set time limit:
        if(this.settings.getBoolean("split_trajectory", false)) {
            // If that time limit has been reached:
            long limit = this.settings.getInt("split_duration", 30) * 60000L;
            // Set progress bar
            this.timeRemaining.setMax((int) (limit/1000));
            this.timeRemaining.setScaleY(3f);

            // Create a CountDownTimer object to adhere to the time limit
            this.autoStop = new CountDownTimer(limit, 1000) {

                /**
                 * {@inheritDoc}
                 * Increment the progress bar to display progress and remaining time. Update the
                 * observed PDR values, and animate icons based on the data.
                 */
                @Override
                public void onTick(long l) {
                    // Increment progress bar
                    timeRemaining.incrementProgressBy(1);
                    // Get new position
                    float[] pdrValues = sensorFusion.getSensorValueMap().get(SensorTypes.PDR);
                    positionX.setText(getString(R.string.x, String.format("%.1f", pdrValues[0])));
                    positionY.setText(getString(R.string.y, String.format("%.1f", pdrValues[1])));
                    // Calculate distance travelled
                    distance += Math.sqrt(Math.pow(pdrValues[0] - previousPosX, 2) + Math.pow(pdrValues[1] - previousPosY, 2));
                    distanceTravelled.setText(getString(R.string.meter, String.format("%.2f", distance)));
                    previousPosX = pdrValues[0];
                    previousPosY = pdrValues[1];
                    // Display elevation and elevator icon when necessary
                    float elevationVal = sensorFusion.getElevation();
                    elevation.setText(getString(R.string.elevation, String.format("%.1f", elevationVal)));
                    if(sensorFusion.getElevator()) elevatorIcon.setVisibility(View.VISIBLE);
                    else elevatorIcon.setVisibility(View.GONE);

                    //Rotate compass image to heading angle
                    compassIcon.setRotation((float) -Math.toDegrees(sensorFusion.passOrientation()));
                }

                /**
                 * {@inheritDoc}
                 * Finish recording and move to the correction fragment.
                 *
                 * @see CorrectionFragment
                 */
                @Override
                public void onFinish() {
                    // Timer done, move to next fragment automatically - will stop recording
                    sensorFusion.stopRecording();
                    NavDirections action = RecordingFragmentDirections.actionRecordingFragmentToCorrectionFragment();
                    Navigation.findNavController(view).navigate(action);
                }
            }.start();
        }
        else {
            // No time limit - use a repeating task to refresh UI.
            this.refreshDataHandler.post(refreshDataTask);
        }
        setupMap(); // Adds the Google Map to the fragment
        setupFloorChangeButton(); // Adds the 'Change Floor' button to the fragment
    }


    /**
     * Links the Google Map to the set container on the interface
     * Displays the map along with a marker and a trajectory mapper and updates screen display
     */
    private void setupMap() {
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.mapContainer);
        if (mapFragment != null) {
            mapFragment.getMapAsync(new OnMapReadyCallback() {

                /**
                 * Calls Google Map to the fragment and calls the set position from the previous fragment
                 * Sets a marker at this location which will rotate to show User direction and move with user
                 * Starts to run a trajectory-tracking line which maps user movements
                 * Moves the Map screen to follow the user
                 * @param googleMap
                 */
                @Override
                public void onMapReady(GoogleMap googleMap) {
                    mMap = googleMap;
                    // Calls the start point set by the user in StartLocation fragment
                    LatLng startLatLng = new LatLng(StartLocationFragment.startPosition[0], StartLocationFragment.startPosition[1]);
                    polyLineArray.add(startLatLng); // Array used to store data points for tracking line

                    float rotation = (float) Math.toDegrees(sensorFusion.passOrientation()); // Takes the device orientation from sensorFusion
                    // Sets a marker which is used to show start location and user position
                    currentMarker = mMap.addMarker(new MarkerOptions()
                            .position(startLatLng) // Starts at set start point
                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.nav_marker)) // Blue arrow icon shows user direction better
                            .rotation(rotation) // Marker rotates with phone orientation
                            .anchor(0.5f, 0.5f) // Marker rotates around its centre
                            .title("Current Position")); // Names the marker

                    // Updates the map image to zoom in on and follow the user
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, zoom));

                    // Setting up the path tracing line
                    PolylineOptions polylineOptions = new PolylineOptions()
                            .addAll(polyLineArray) // Append all collected position data to the array
                            .color(Color.RED) // Set the polyline color to red
                            .width(15); // Set a slightly thicker line
                    // Draws the polyline onto the map with updated array
                    pdrPolyline = mMap.addPolyline(polylineOptions);
                }
            });
        }
    }

    // Define rectangular boundary of the Nucleus Building using SW and NE corners
    private final LatLngBounds nucleusBoundary = new LatLngBounds(
            new LatLng(55.9228224, -3.1745969), // SW corner
            new LatLng(55.9233165, -3.1738757)  // NE corner
    );

    // Define rectangular boundary of the Library Building using SW and NE corners
    private final LatLngBounds libraryBoundary = new LatLngBounds(
            new LatLng(55.9228151, -3.1751705), // SW corner
            new LatLng(55.9230234, -3.1747960)  // NE corner
    );


    /**
     * Removes any overlays currently displaying on the map
     * Clears Overlay and Building tracker variables
     */
    private void removeCurrentOverlay() {
        if (currentOverlay != null) {
            currentOverlay.remove();
            currentOverlay = null; // Reset 'current overlay' tracking
            currentBuilding = ""; // Reset 'current building' tracking
        }
    }


    /**
     * Checks whether user is in a mapped building and, if so, then which
     * Removes any overlays if user is not in a mapped building
     * If user is in a mapped building, checks if it is a different building from before
     * If in a different building then changes overlays, otherwise moves on
     * @param newPosition
     */
    private void checkAndDisplayOverlay(LatLng newPosition) {
        // Determine which building the user is in or if not in a building
        String newBuilding = nucleusBoundary.contains(newPosition) ? "nucleus" :
                libraryBoundary.contains(newPosition) ? "library" : "";

        // Remove any overlays if not in a mapped building
        if (newBuilding.isEmpty()) {
            removeCurrentOverlay();
            currentBuilding = ""; // Reset current building tracking
            selectedFloor = "G"; // Default to Ground floor when outside any building
            return;
        }

        // Check if user is in a different building from before or if there is no overlay yet displayed
        // Implicitly handles case of user entering a new building and shows default ground floor
        if (!newBuilding.equals(currentBuilding) || currentOverlay == null) {
            currentBuilding = newBuilding; // Update the current building tracker

            // Displays corresponding building overlay
            showOverlayForFloor(selectedFloor, currentBuilding); // selectedFloor initialised to G by default
        }
    }


    /**
     * Checks if selected floor is different to that of a shown overlay
     * If different then it removes any existing overlays, fetches required overlays and displays them
     * @param floor
     * @param building
     */
    private void showOverlayForFloor(String floor, String building) {
        // Only update overlay and currentFloor tracker if different to current display
        if (!floor.equals(currentFloor) || currentOverlay == null) {
            currentFloor = floor; // Update the current floor tracker to the new selection
            removeCurrentOverlay(); // Remove any existing overlay

            // Fetch the resource ID for the current floor and building
            int resourceId = getResourceIdForFloor(floor, building);

            // Determine the boundary for the overlay based on the current building
            LatLngBounds targetBoundary = "nucleus".equals(building) ? nucleusBoundary : libraryBoundary;

            // Create and set the new overlay options
            GroundOverlayOptions options = new GroundOverlayOptions()
                    .image(BitmapDescriptorFactory.fromResource(resourceId))
                    .positionFromBounds(targetBoundary);

            // Display the overlay on the map
            currentOverlay = mMap.addGroundOverlay(options);
        }
    }


    /**
     * Reads the building and floor from the method arguments given
     * Returns the ID for the appropriate drawable file for the overlay
     * @param floor
     * @param building
     * @return
     */
    private int getResourceIdForFloor(String floor, String building) {
        if ("nucleus".equals(building)) {
            switch (floor) {
                case "LG": return R.drawable.nucleuslg;
                case "G": return R.drawable.nucleusg;
                case "First Floor": return R.drawable.nucleus1;
                case "Second Floor": return R.drawable.nucleus2;
                case "Third Floor": return R.drawable.nucleus3;
                default: return R.drawable.nucleusg; // Default to Ground Floor
            }
        } else if ("library".equals(building)) {
            switch (floor) {
                case "G": return R.drawable.libraryg;
                case "First Floor": return R.drawable.library1;
                case "Second Floor": return R.drawable.library2;
                case "Third Floor": return R.drawable.library3;
                default: return R.drawable.libraryg; // Default to Ground Floor for library
            }
        }
        return R.drawable.nucleusg; // Fallback default if no previous options match
    }


    /**
     * Links Pop-Up Menu to "Change Floor" button on the interface
     * Allows user to select between different floors from an interactive menu
     * Button is deactivated when not in a mapped building
     * Will change the available floors to select depending on current building
     */
    public void setupFloorChangeButton() {
        Button buttonChangeFloor = getView().findViewById(R.id.buttonChangeFloor);
        buttonChangeFloor.setOnClickListener(v -> {
            // Set up Pop-Up Menu to select floor
            PopupMenu floorMenu = new PopupMenu(getContext(), v);

            // Dynamically add menu items based on the current building
            if ("nucleus".equals(currentBuilding)) {
                floorMenu.getMenu().add("LG");
                floorMenu.getMenu().add("G");
                floorMenu.getMenu().add("First Floor");
                floorMenu.getMenu().add("Second Floor");
                floorMenu.getMenu().add("Third Floor");
            } else if ("library".equals(currentBuilding)) {
                // Library does not have an "LG" floor
                floorMenu.getMenu().add("G");
                floorMenu.getMenu().add("First Floor");
                floorMenu.getMenu().add("Second Floor");
                floorMenu.getMenu().add("Third Floor");
            } else { return; // Exit early to avoid showing an empty menu
              }

            // Re-enable the button in case it was previously disabled
            buttonChangeFloor.setEnabled(true);

            // Handle menu item clicks
            floorMenu.setOnMenuItemClickListener(item -> {
                // Saves user-selected floor to call the appropriate overlay
                selectedFloor = item.getTitle().toString();
                showOverlayForFloor(selectedFloor, currentBuilding); // Display selected floor overlay
                return true;
            });
            floorMenu.show();
        });
    }


    /**
     * Runnable task used to refresh UI elements with live data.
     * Has to be run through a Handler object to be able to alter UI elements
     */
    private final Runnable refreshDataTask = new Runnable() {
        @Override
        public void run() {

            //////////////////////////// PDR DATA HANDLING ////////////////////////////
            // Get new position
            float[] pdrValues = sensorFusion.getSensorValueMap().get(SensorTypes.PDR);
            positionX.setText(getString(R.string.x, String.format("%.1f", pdrValues[0])));
            positionY.setText(getString(R.string.y, String.format("%.1f", pdrValues[1])));

            // Calculate distance travelled
            distance += Math.sqrt(Math.pow(pdrValues[0] - previousPosX, 2) + Math.pow(pdrValues[1] - previousPosY, 2));
            distanceTravelled.setText(getString(R.string.meter, String.format("%.2f", distance)));
            previousPosX = pdrValues[0];
            previousPosY = pdrValues[1];

            // Display elevation and elevator icon when necessary
            float elevationVal = sensorFusion.getElevation();
            elevation.setText(getString(R.string.elevation, String.format("%.1f", elevationVal)));
            if(sensorFusion.getElevator()) elevatorIcon.setVisibility(View.VISIBLE);
            else elevatorIcon.setVisibility(View.GONE);

            // Rotate compass image to heading angle
            compassIcon.setRotation((float) -Math.toDegrees(sensorFusion.passOrientation()));
            //////////////////////////// PDR DATA HANDLING ////////////////////////////


            // Obtain the new device orientation and dynamically update current marker rotation
            float rotation = (float) Math.toDegrees(sensorFusion.passOrientation());
            if (currentMarker != null && mMap != null) {
                currentMarker.setRotation(rotation); // Rotate marker with the device
            }

            // Update the marker position based on PDR data
            if (mMap != null && currentMarker != null) {
                double deltaX = pdrValues[0]; // Collecting PDR X displacement in meters
                double deltaY = pdrValues[1]; // Collecting PDR Y displacement in meters
                // 1 degree of latitude ≈ 111320m
                double newLat = StartLocationFragment.startPosition[0] + (deltaY / 111320);
                // 1 degree of longitude ≈ 111320cos(latitude)m
                double newLng = StartLocationFragment.startPosition[1] + (deltaX / (111320 * Math.cos(startLatRadians)));

                // Saves the updated user coordinates and updates the marker accordingly
                LatLng newPosition = new LatLng(newLat, newLng);
                currentMarker.setPosition(newPosition);

                // Only check if any change in overlay is needed when moving or when first starting
                if (lastPosition == null || !lastPosition.equals(newPosition)) {
                    checkAndDisplayOverlay(newPosition);
                }

                // Adjust "Change Floor" button visibility/state based on if inside a mapped building
                View buttonChangeFloor = getView().findViewById(R.id.buttonChangeFloor);
                if ("".equals(currentBuilding)) {
                    buttonChangeFloor.setVisibility(View.GONE); // Button not visible when not in a mapped building
                } else {
                    buttonChangeFloor.setVisibility(View.VISIBLE); // Button visible when in mapped building
                }

                // Add the new position to the polyline array
                polyLineArray.add(newPosition);
                // Update the polyline on the map
                pdrPolyline.setPoints(polyLineArray);

                // Move the map display to centre the new position
                mMap.animateCamera(CameraUpdateFactory.newLatLng(newPosition));
            }

            // Uncomment to make the map rotate with the device
//            // Rotate the map view to align with the device orientation (updates every 500ms)
//            if (mMap != null) {
//                CameraPosition currentCameraPosition = mMap.getCameraPosition();
//                CameraPosition cameraPosition = new CameraPosition.Builder()
//                        .target(currentMarker.getPosition()) // Keep the current position centered
//                        .zoom(currentCameraPosition.zoom) // Use current zoom level
//                        .bearing(rotation) // Rotate the display
//                        .tilt(currentCameraPosition.tilt) // Keep the current tilt
//                        .build();
                  // Show display rotation and update every 0.5s
//                mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition), 500, null);
//            }

            // Loop the task again to keep refreshing the data
            refreshDataHandler.postDelayed(refreshDataTask, 500);
        }
    };


    /**
     * Displays a blinking red dot to signify an ongoing recording.
     * @see Animation for makin the red dot blink.
     */
    private void blinkingRecording() {
        //Initialise Image View
        this.recIcon = getView().findViewById(R.id.redDot);
        //Configure blinking animation
        Animation blinking_rec = new AlphaAnimation(1, 0);
        blinking_rec.setDuration(800);
        blinking_rec.setInterpolator(new LinearInterpolator());
        blinking_rec.setRepeatCount(Animation.INFINITE);
        blinking_rec.setRepeatMode(Animation.REVERSE);
        recIcon.startAnimation(blinking_rec);
    }


    /**
     * {@inheritDoc}
     * Stops ongoing refresh task, but not the countdown timer which stops automatically
     */
    @Override
    public void onPause() {
        refreshDataHandler.removeCallbacks(refreshDataTask);
        super.onPause();
    }


    /**
     * {@inheritDoc}
     * Restarts UI refreshing task when no countdown task is in progress
     */
    @Override
    public void onResume() {
        if(!this.settings.getBoolean("split_trajectory", false)) {
            refreshDataHandler.postDelayed(refreshDataTask, 500);
        }
        super.onResume();
    }
}