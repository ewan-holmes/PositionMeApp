package com.openpositioning.PositionMe.fragments;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupMenu;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.openpositioning.PositionMe.R;
import com.openpositioning.PositionMe.sensors.SensorFusion;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
/**
 * A simple {@link Fragment} subclass. The startLocation fragment is displayed before the trajectory
 * recording starts. This fragment displays a map in which the user can adjust their location to
 * correct the PDR when it is complete
 *
 * @see HomeFragment the previous fragment in the nav graph.
 * @see RecordingFragment the next fragment in the nav graph.
 * @see SensorFusion the class containing sensors and recording.
 *
 * @author Virginia Cangelosi
 */

public class StartLocationFragment extends Fragment implements OnMapReadyCallback {

    private Button button;
    private SensorFusion sensorFusion = SensorFusion.getInstance();
    private LatLng position;
    public static float[] startPosition = new float[2];
    private float zoom = 19f;
    private GoogleMap mMap; // Adding class member variable for GoogleMap

    public StartLocationFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
        View rootView = inflater.inflate(R.layout.fragment_startlocation, container, false);

        startPosition = sensorFusion.getGNSSLatitude(false);
        if(startPosition[0] == 0 && startPosition[1] == 0){
            zoom = 1f;
        } else {
            zoom = 19f;
        }

        SupportMapFragment supportMapFragment = (SupportMapFragment)
                getChildFragmentManager().findFragmentById(R.id.startMap);
        supportMapFragment.getMapAsync(this); // Register this fragment as the callback

        return rootView;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap; // Assign the GoogleMap object
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        mMap.getUiSettings().setCompassEnabled(true);
        mMap.getUiSettings().setTiltGesturesEnabled(true);
        mMap.getUiSettings().setRotateGesturesEnabled(true);
        mMap.getUiSettings().setScrollGesturesEnabled(true);

        position = new LatLng(startPosition[0], startPosition[1]);
        mMap.addMarker(new MarkerOptions().position(position).title("Start Position")).setDraggable(true);
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(position, zoom));

        mMap.setOnMarkerDragListener(new GoogleMap.OnMarkerDragListener() {
            @Override
            public void onMarkerDragStart(Marker marker) {}

            @Override
            public void onMarkerDragEnd(Marker marker) {
                startPosition[0] = (float) marker.getPosition().latitude;
                startPosition[1] = (float) marker.getPosition().longitude;
            }

            @Override
            public void onMarkerDrag(Marker marker) {}
        });
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.button = (Button) getView().findViewById(R.id.startLocationDone);
        this.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sensorFusion.startRecording();
                sensorFusion.setStartGNSSLatitude(startPosition);

                NavDirections action = StartLocationFragmentDirections.actionStartLocationFragmentToRecordingFragment();
                Navigation.findNavController(view).navigate(action);
            }
        });
        setupMapTypeButton(view);
    }

    /**
     * Links Pop-Up Menu to "Map Type" button on the interface
     * Allows user to choose between different Map types from interactive menu
     * @param rootView
     */
    private void setupMapTypeButton(View rootView) {
        // Linking method to the interface button
        Button mapTypeButton = rootView.findViewById(R.id.buttonMapType);
        mapTypeButton.setOnClickListener(new View.OnClickListener() {

            /**
             * OnClick listener for button to change map type
             * When button clicked a Pop-Up menu brings up selectable map types for user
             */
            @Override
            public void onClick(View v) {
                // Creating Pop-Up Menu
                PopupMenu popupMenu = new PopupMenu(getActivity(), v);
                // Inflating the Pop-Up Menu with the map types
                popupMenu.getMenu().add(Menu.NONE, GoogleMap.MAP_TYPE_NORMAL, Menu.NONE, "Normal");
                popupMenu.getMenu().add(Menu.NONE, GoogleMap.MAP_TYPE_SATELLITE, Menu.NONE, "Satellite");
                popupMenu.getMenu().add(Menu.NONE, GoogleMap.MAP_TYPE_TERRAIN, Menu.NONE, "Terrain");
                popupMenu.getMenu().add(Menu.NONE, GoogleMap.MAP_TYPE_HYBRID, Menu.NONE, "Hybrid");

                // Setting up click listener for the menu options
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

                    /**
                     * OnMenuItemClick listener for map type Pop-Up menu options
                     * When an option is clicked it will set the google map to that type
                     */
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        // Setting map type based on user selection
                        mMap.setMapType(item.getItemId());
                        return true;
                    }
                });

                // Showing the Pop-Up Menu
                popupMenu.show();
            }
        });
    }


}

